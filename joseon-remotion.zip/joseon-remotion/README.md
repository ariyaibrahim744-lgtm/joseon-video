# Joseon Documentary — Remotion Project

Video dokumenter 14 menit tentang Dinasti Joseon, dibangun sebagai 10 scene komponen React di atas Remotion.

## Menjalankan

```bash
npm install
npm start
```

Studio Remotion akan terbuka di browser (`http://localhost:3000`) menampilkan komposisi `JoseonDocumentary`.

## Render ke MP4

```bash
npm run build
```

Hasil ada di `out/joseon-documentary.mp4`.

## Struktur

- `src/theme.ts` — token warna, font, dan tabel durasi tiap scene (persis mengikuti naskah).
- `src/fonts.ts` — memuat Noto Serif KR (judul) & Noto Sans KR (isi) dari Google Fonts.
- `src/components/` — elemen bersama: `LatticeBackground` (pola kisi hanok, signature visual), `SealStamp` (segel merah pengganti angka scene), `InkStroke` (garis kuas), `KineticCaption` (narasi baris-per-baris), `Motif` (ilustrasi garis khas tiap scene), `SceneShell` (layout dasar dipakai semua scene).
- `src/scenes/Scene01Hook.tsx` ... `Scene10Closing.tsx` — satu file per scene, isi konten diambil langsung dari naskah.
- `src/JoseonVideo.tsx` — merangkai semua scene dengan `<Sequence>` sesuai tabel waktu.
- `src/Root.tsx` — registrasi komposisi `JoseonDocumentary` (1920x1080, 30fps, 25.200 frame / 14:00 menit).

## Yang perlu kamu tambahkan sendiri

- **Narasi audio**: proyek ini belum menyertakan file suara. Tambahkan `<Audio src={staticFile('narasi.mp3')} />` di `JoseonVideo.tsx` per scene bila sudah punya rekaman voice-over, lalu sesuaikan timing `KineticCaption` agar pas dengan audio.
- **Aset visual nyata**: saat ini latar memakai ilustrasi garis (SVG) buatan kode, bukan foto/lukisan asli. Kalau punya gambar/lukisan Joseon yang lisensinya jelas, taruh di folder `public/` lalu ganti `<Motif />` dengan `<Img src={staticFile(...)} />` di scene terkait.
- **Musik latar**: tambahkan lewat `<Audio>` di level `JoseonVideo.tsx`, volume rendah agar tak menutupi voice-over.
