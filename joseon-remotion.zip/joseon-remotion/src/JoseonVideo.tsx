import React from 'react';
import { AbsoluteFill, Sequence } from 'remotion';
import { fps, sceneDurationsSec, secToFrames } from './theme';

import { Scene01Hook } from './scenes/Scene01Hook';
import { Scene02Founding } from './scenes/Scene02Founding';
import { Scene03Confucian } from './scenes/Scene03Confucian';
import { Scene04Sejong } from './scenes/Scene04Sejong';
import { Scene05Culture } from './scenes/Scene05Culture';
import { Scene06War } from './scenes/Scene06War';
import { Scene07Isolation } from './scenes/Scene07Isolation';
import { Scene08Fall } from './scenes/Scene08Fall';
import { Scene09Legacy } from './scenes/Scene09Legacy';
import { Scene10Closing } from './scenes/Scene10Closing';

const scenes = [
	Scene01Hook,
	Scene02Founding,
	Scene03Confucian,
	Scene04Sejong,
	Scene05Culture,
	Scene06War,
	Scene07Isolation,
	Scene08Fall,
	Scene09Legacy,
	Scene10Closing,
];

/**
 * Menyusun 10 scene berurutan mengikuti tabel durasi persis dari naskah
 * (lihat "Ringkasan Struktur" di naskah-joseon-14menit.md).
 * Total: 840 detik = 25.200 frame @30fps = 14:00 menit.
 */
export const JoseonVideo: React.FC = () => {
	let cursor = 0;

	return (
		<AbsoluteFill>
			{scenes.map((SceneComponent, i) => {
				const durationInFrames = secToFrames(sceneDurationsSec[i]);
				const from = cursor;
				cursor += durationInFrames;

				return (
					<Sequence key={i} from={from} durationInFrames={durationInFrames}>
						<SceneComponent />
					</Sequence>
				);
			})}
		</AbsoluteFill>
	);
};
