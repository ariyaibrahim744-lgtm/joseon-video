// theme.ts — token desain tunggal. Semua scene mengambil warna/tipografi dari sini
// supaya konsisten dan mudah diubah dari satu tempat.

export const colors = {
	paper: '#EDE6D6', // dasar hanji (kertas mulberry tradisional)
	paperDeep: '#E1D7C0',
	ink: '#1A1815', // hitam tinta sumi
	indigo: '#1C2B4A', // biru istana / jubah kerajaan
	cinnabar: '#A13D2E', // merah segel / dancheong
	brass: '#B8923A', // aksen emas/kuningan
	jade: '#3F5A4D', // hijau giok, dipakai sangat terbatas
	cream: '#F6F1E4',
} as const;

export const fonts = {
	display: 'Noto Serif KR',
	body: 'Noto Sans KR',
} as const;

export const fps = 30;

// Tabel durasi persis dari naskah (dalam detik), dikonversi ke frame.
export const sceneDurationsSec = [45, 105, 120, 120, 90, 90, 90, 90, 60, 30] as const;

export const totalDurationInFrames = sceneDurationsSec.reduce(
	(sum, s) => sum + s * fps,
	0
); // = 25200 frame (14:00 @30fps)

export const secToFrames = (s: number) => Math.round(s * fps);
