import React from 'react';
import { Composition } from 'remotion';
import { JoseonVideo } from './JoseonVideo';
import { fps, totalDurationInFrames } from './theme';
import './fonts';

export const RemotionRoot: React.FC = () => {
	return (
		<Composition
			id="JoseonDocumentary"
			component={JoseonVideo}
			durationInFrames={totalDurationInFrames}
			fps={fps}
			width={1920}
			height={1080}
		/>
	);
};
