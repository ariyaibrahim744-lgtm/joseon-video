import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { PaperBackground } from './PaperBackground';
import { LatticeBackground } from './LatticeBackground';
import { SealStamp } from './SealStamp';
import { InkStroke } from './InkStroke';
import { KineticCaption } from './KineticCaption';
import { colors, fonts } from '../theme';

export type SceneShellProps = {
	/** Label Hangeul singkat untuk segel, mis. "건국". */
	sealHangeul: string;
	/** Label Latin singkat untuk segel, mis. "1392". */
	sealLabel: string;
	/** Judul besar scene. */
	title: string;
	/** Anak-kalimat kecil di bawah judul (opsional). */
	subtitle?: string;
	/** Narasi, akan tampil sebagai caption kinetik baris per baris. */
	narration: string[];
	accent?: string;
	children?: React.ReactNode;
};

export const SceneShell: React.FC<SceneShellProps> = ({
	sealHangeul,
	sealLabel,
	title,
	subtitle,
	narration,
	accent = colors.indigo,
	children,
}) => {
	const frame = useCurrentFrame();
	const titleOpacity = interpolate(frame, [8, 22], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
	const titleY = interpolate(frame, [8, 22], [16, 0], { extrapolateRight: 'clamp' });

	return (
		<AbsoluteFill style={{ backgroundColor: colors.paper }}>
			<PaperBackground />
			<LatticeBackground accent={accent} />

			{/* Lapisan konten tambahan spesifik tiap scene (mis. ilustrasi/motif). */}
			{children}

			<AbsoluteFill style={{ padding: '90px 120px', justifyContent: 'space-between' }}>
				<SealStamp hangeul={sealHangeul} label={sealLabel} />

				<div style={{ maxWidth: 1180 }}>
					<div
						style={{
							opacity: titleOpacity,
							transform: `translateY(${titleY}px)`,
						}}
					>
						<h1
							style={{
								fontFamily: fonts.display,
								fontWeight: 900,
								fontSize: 68,
								color: colors.ink,
								margin: 0,
								lineHeight: 1.15,
							}}
						>
							{title}
						</h1>
						{subtitle ? (
							<p
								style={{
									fontFamily: fonts.body,
									fontSize: 26,
									color: accent,
									marginTop: 10,
									fontWeight: 500,
								}}
							>
								{subtitle}
							</p>
						) : null}
						<div style={{ marginTop: 18 }}>
							<InkStroke color={accent} delay={20} />
						</div>
					</div>

					<div style={{ marginTop: 34 }}>
						<KineticCaption lines={narration} accent={colors.ink} />
					</div>
				</div>
			</AbsoluteFill>
		</AbsoluteFill>
	);
};
