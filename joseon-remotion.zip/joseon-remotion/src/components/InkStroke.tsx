import React from 'react';
import { interpolate, useCurrentFrame } from 'remotion';
import { colors } from '../theme';

type Props = {
	color?: string;
	width?: number;
	delay?: number;
};

/** Satu goresan kuas tinta yang "ditulis" dari kiri ke kanan. */
export const InkStroke: React.FC<Props> = ({ color = colors.ink, width = 240, delay = 0 }) => {
	const frame = useCurrentFrame();
	const progress = interpolate(frame - delay, [0, 20], [0, 1], {
		extrapolateLeft: 'clamp',
		extrapolateRight: 'clamp',
	});

	return (
		<svg width={width} height={14} style={{ overflow: 'visible' }}>
			<path
				d={`M2,7 Q${width / 2},2 ${width - 2},7`}
				stroke={color}
				strokeWidth={4}
				strokeLinecap="round"
				fill="none"
				strokeDasharray={width}
				strokeDashoffset={width * (1 - progress)}
				opacity={0.85}
			/>
		</svg>
	);
};
