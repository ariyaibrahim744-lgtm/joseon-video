import React from 'react';
import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { colors, fonts } from '../theme';

type Props = {
	/** Label singkat dalam aksara Hangeul, mis. "건국" (pendirian). */
	hangeul: string;
	/** Terjemahan/label Latin pendek, mis. "1392". */
	label: string;
};

/**
 * Meniru "dojang" (도장) — stempel segel merah yang dulu membubuhkan
 * legitimasi pada dokumen kerajaan Joseon. Di sini dipakai sebagai
 * penanda pembuka tiap scene: "menstempel" judul ke layar.
 */
export const SealStamp: React.FC<Props> = ({ hangeul, label }) => {
	const frame = useCurrentFrame();
	const { fps } = useVideoConfig();

	// Efek "dihentak" seperti stempel ditekan ke kertas.
	const stamp = spring({ frame, fps, config: { damping: 12, mass: 0.6 }, durationInFrames: 18 });
	const scale = interpolate(stamp, [0, 1], [1.4, 1]);
	const opacity = interpolate(frame, [0, 8], [0, 1], { extrapolateRight: 'clamp' });
	const jitter = interpolate(stamp, [0, 1], [-3, 0]);

	return (
		<div
			style={{
				display: 'inline-flex',
				flexDirection: 'column',
				alignItems: 'center',
				justifyContent: 'center',
				width: 108,
				height: 108,
				borderRadius: '50%',
				border: `3px solid ${colors.cinnabar}`,
				color: colors.cinnabar,
				opacity: opacity * 0.92,
				transform: `scale(${scale}) rotate(${jitter}deg)`,
				fontFamily: fonts.display,
			}}
		>
			<span style={{ fontSize: 30, fontWeight: 700, lineHeight: 1.1 }}>{hangeul}</span>
			<span
				style={{
					fontSize: 13,
					letterSpacing: 2,
					marginTop: 4,
					fontFamily: fonts.body,
					fontWeight: 500,
				}}
			>
				{label}
			</span>
		</div>
	);
};
