import React, { useMemo } from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { colors } from '../theme';

type Props = {
	accent?: string;
	/** Kepadatan kisi — makin besar makin rapat garisnya. */
	density?: number;
	/** Opasitas dasar pola, dijaga rendah agar teks tetap terbaca. */
	baseOpacity?: number;
};

/**
 * Pola kisi kayu jendela hanok tradisional (changsal, 창살).
 * Ini adalah "signature element" video: satu motif visual yang konsisten
 * muncul di setiap scene, "bernapas" pelan mengikuti frame, sebagai
 * pengingat visual bahwa seluruh cerita terjadi di dalam arsitektur Joseon.
 */
export const LatticeBackground: React.FC<Props> = ({
	accent = colors.ink,
	density = 64,
	baseOpacity = 0.08,
}) => {
	const frame = useCurrentFrame();

	// Napas pelan: skala & opasitas berosilasi sangat halus, siklus ~6 detik.
	const breathe = Math.sin(frame / 90) * 0.5 + 0.5;
	const opacity = interpolate(breathe, [0, 1], [baseOpacity * 0.7, baseOpacity]);
	const scale = interpolate(breathe, [0, 1], [1, 1.015]);

	const lines = useMemo(() => {
		const items: { x1: number; y1: number; x2: number; y2: number }[] = [];
		for (let i = 0; i <= density; i++) {
			const pos = (i / density) * 100;
			items.push({ x1: pos, y1: 0, x2: pos, y2: 100 });
			items.push({ x1: 0, y1: pos, x2: 100, y2: pos });
		}
		return items;
	}, [density]);

	return (
		<AbsoluteFill
			style={{
				transform: `scale(${scale})`,
				opacity,
			}}
		>
			<svg
				viewBox="0 0 100 100"
				preserveAspectRatio="none"
				width="100%"
				height="100%"
			>
				{lines.map((l, i) => (
					<line
						key={i}
						x1={l.x1}
						y1={l.y1}
						x2={l.x2}
						y2={l.y2}
						stroke={accent}
						strokeWidth={0.06}
					/>
				))}
			</svg>
		</AbsoluteFill>
	);
};
