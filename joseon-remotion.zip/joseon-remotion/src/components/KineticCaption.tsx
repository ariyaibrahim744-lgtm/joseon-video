import React, { useMemo } from 'react';
import { interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { colors, fonts } from '../theme';

type Props = {
	lines: string[];
	/** Frame lokal (relatif ke scene) tempat caption mulai muncul. */
	startAt?: number;
	accent?: string;
};

const FADE = 12; // frame fade in/out per baris

/**
 * Membagi durasi scene secara proporsional terhadap panjang tiap kalimat
 * (kalimat lebih panjang mendapat waktu tayang lebih lama), lalu me-render
 * hanya baris yang sedang "aktif" pada frame berjalan.
 */
export const KineticCaption: React.FC<Props> = ({ lines, startAt = 20, accent = colors.ink }) => {
	const frame = useCurrentFrame();
	const { durationInFrames } = useVideoConfig();

	const windows = useMemo(() => {
		const available = Math.max(durationInFrames - startAt - 10, lines.length * FADE);
		const weights = lines.map((l) => Math.max(l.length, 10));
		const totalWeight = weights.reduce((a, b) => a + b, 0);
		let cursor = startAt;
		return lines.map((line, i) => {
			const dur = (weights[i] / totalWeight) * available;
			const win = { line, from: cursor, to: cursor + dur };
			cursor += dur;
			return win;
		});
	}, [lines, durationInFrames, startAt]);

	const active = windows.find((w) => frame >= w.from && frame <= w.to);
	if (!active) return null;

	const opacity = interpolate(
		frame,
		[active.from, active.from + FADE, active.to - FADE, active.to],
		[0, 1, 1, 0],
		{ extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }
	);
	const translateY = interpolate(
		frame,
		[active.from, active.from + FADE],
		[14, 0],
		{ extrapolateRight: 'clamp' }
	);

	return (
		<div
			style={{
				opacity,
				transform: `translateY(${translateY}px)`,
				fontFamily: fonts.body,
				fontSize: 30,
				fontWeight: 500,
				lineHeight: 1.5,
				color: accent,
				maxWidth: 980,
			}}
		>
			{active.line}
		</div>
	);
};
