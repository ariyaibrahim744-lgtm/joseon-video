import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { colors } from '../theme';

export type MotifVariant =
	| 'mountains' // pegunungan — lanskap semenanjung
	| 'palaceRoof' // atap istana bertingkat
	| 'gate' // gerbang istana / pintu tertutup
	| 'characters' // aksara Hangeul melayang
	| 'textilePattern' // motif kain hanbok
	| 'waves' // gelombang laut / kapal
	| 'flagFall' // bendera turun (keruntuhan)
	| 'skyline' // siluet kota modern
	| 'sunburst'; // matahari terbit — penutup harapan

const paths: Record<MotifVariant, string> = {
	mountains:
		'M0,80 L15,55 L28,68 L42,40 L58,66 L72,48 L88,70 L100,58 L100,100 L0,100 Z',
	palaceRoof:
		'M10,60 Q50,20 90,60 L90,66 L10,66 Z M20,66 Q50,40 80,66',
	gate: 'M20,90 L20,30 Q50,10 80,30 L80,90 M20,90 L80,90',
	characters: '', // dirender sebagai teks, bukan path
	textilePattern: '',
	waves:
		'M0,70 Q10,60 20,70 T40,70 T60,70 T80,70 T100,70 L100,100 L0,100 Z',
	flagFall: 'M30,10 L30,90 M30,10 L70,22 L30,34',
	skyline:
		'M0,90 L8,90 L8,60 L18,60 L18,75 L28,75 L28,45 L38,45 L38,90 L52,90 L52,55 L62,55 L62,90 L100,90 L100,100 L0,100 Z',
	sunburst: '',
};

type Props = {
	variant: MotifVariant;
	accent?: string;
	opacity?: number;
};

/** Ilustrasi garis latar minim, satu per scene, untuk menghindari layar kosong tanpa berlebihan. */
export const Motif: React.FC<Props> = ({ variant, accent = colors.indigo, opacity = 0.16 }) => {
	const frame = useCurrentFrame();
	const drift = interpolate(frame, [0, 300], [0, -6], { extrapolateRight: 'clamp' });

	if (variant === 'characters') {
		const glyphs = ['ㅎ', 'ㅏ', 'ㄴ', 'ㄱ', 'ㅡ', 'ㄹ'];
		return (
			<AbsoluteFill style={{ opacity }}>
				{glyphs.map((g, i) => (
					<span
						key={i}
						style={{
							position: 'absolute',
							right: 80 + i * 90,
							top: 120 + (i % 2 === 0 ? 0 : 60),
							fontSize: 90,
							color: accent,
							transform: `translateY(${drift}px)`,
						}}
					>
						{g}
					</span>
				))}
			</AbsoluteFill>
		);
	}

	if (variant === 'textilePattern') {
		return (
			<AbsoluteFill style={{ opacity }}>
				<svg width="100%" height="100%">
					<pattern id="textile" width={48} height={48} patternUnits="userSpaceOnUse">
						<circle cx={24} cy={24} r={5} fill="none" stroke={accent} strokeWidth={1.4} />
					</pattern>
					<rect width="100%" height="100%" fill="url(#textile)" />
				</svg>
			</AbsoluteFill>
		);
	}

	if (variant === 'sunburst') {
		return (
			<AbsoluteFill style={{ opacity, alignItems: 'center', justifyContent: 'flex-end' }}>
				<svg width={520} height={260} viewBox="0 0 100 50" style={{ marginBottom: 40 }}>
					<circle cx={50} cy={50} r={30} fill="none" stroke={accent} strokeWidth={1.2} />
					{Array.from({ length: 12 }).map((_, i) => (
						<line
							key={i}
							x1={50}
							y1={50}
							x2={50 + 45 * Math.cos((i * Math.PI) / 6)}
							y2={50 + 45 * Math.sin((i * Math.PI) / 6)}
							stroke={accent}
							strokeWidth={0.6}
						/>
					))}
				</svg>
			</AbsoluteFill>
		);
	}

	return (
		<AbsoluteFill style={{ opacity, transform: `translateX(${drift}px)` }}>
			<svg viewBox="0 0 100 100" width="100%" height="100%" preserveAspectRatio="none">
				<path d={paths[variant]} fill="none" stroke={accent} strokeWidth={0.8} />
			</svg>
		</AbsoluteFill>
	);
};
