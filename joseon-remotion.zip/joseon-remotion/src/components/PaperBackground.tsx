import React from 'react';
import { AbsoluteFill } from 'remotion';
import { colors } from '../theme';

type Props = {
	tint?: string;
};

/** Dasar "kertas hanji" — gradasi hangat, bukan warna flat, agar terasa bertekstur. */
export const PaperBackground: React.FC<Props> = ({ tint = colors.paper }) => {
	return (
		<AbsoluteFill
			style={{
				background: `radial-gradient(120% 90% at 15% 10%, ${colors.cream} 0%, ${tint} 55%, ${colors.paperDeep} 100%)`,
			}}
		/>
	);
};
