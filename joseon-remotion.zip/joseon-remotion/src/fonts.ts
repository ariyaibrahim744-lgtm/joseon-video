import { loadFont as loadDisplay } from '@remotion/google-fonts/NotoSerifKR';
import { loadFont as loadBody } from '@remotion/google-fonts/NotoSansKR';

const { fontFamily: displayFamily } = loadDisplay('normal', {
	weights: ['500', '700', '900'],
});
const { fontFamily: bodyFamily } = loadBody('normal', {
	weights: ['400', '500', '700'],
});

export const displayFontFamily = displayFamily;
export const bodyFontFamily = bodyFamily;
