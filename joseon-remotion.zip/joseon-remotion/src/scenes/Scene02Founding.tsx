import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene02Founding: React.FC = () => (
	<SceneShell
		sealHangeul="건국"
		sealLabel="1392"
		title="Lahirnya Joseon"
		subtitle="Dari kudeta militer menjadi dinasti baru"
		accent={colors.cinnabar}
		narration={[
			'Pada akhir abad ke-14, Dinasti Goryeo yang telah berkuasa hampir 500 tahun mulai runtuh.',
			'Jenderal Yi Seong-gye diperintahkan menyerang Tiongkok — namun ia membelokkan pasukannya dan menggulingkan raja.',
			'Pada 1392, ia menobatkan diri sebagai raja pertama Joseon, merujuk kerajaan kuno Gojoseon.',
			'Ibu kota dipindahkan ke Hanyang — yang kini kita kenal sebagai Seoul.',
		]}
	>
		<Motif variant="palaceRoof" accent={colors.cinnabar} />
	</SceneShell>
);
