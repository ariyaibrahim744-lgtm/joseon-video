import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene09Legacy: React.FC = () => (
	<SceneShell
		sealHangeul="유산"
		sealLabel="WARISAN"
		title="Warisan yang Abadi"
		subtitle="Dari istana kuno ke Korea modern"
		accent={colors.jade}
		narration={[
			'Meski dinastinya telah tiada, warisan Joseon tidak pernah benar-benar hilang.',
			'Hangeul kini menjadi aksara resmi di Korea Selatan maupun Korea Utara.',
			'Nilai Konfusianisme tentang pendidikan dan keluarga masih membentuk masyarakat Korea modern.',
			'Istana seperti Gyeongbokgung kini berdiri sebagai situs warisan dunia bagi jutaan pengunjung.',
		]}
	>
		<Motif variant="skyline" accent={colors.jade} />
	</SceneShell>
);
