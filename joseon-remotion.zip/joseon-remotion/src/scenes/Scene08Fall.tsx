import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene08Fall: React.FC = () => (
	<SceneShell
		sealHangeul="망국"
		sealLabel="1897–1910"
		title="Keruntuhan dan Akhir Dinasti"
		subtitle="Dari Kekaisaran Korea hingga aneksasi Jepang"
		accent={colors.cinnabar}
		narration={[
			'Raja Gojong berusaha memodernisasi negara, bahkan mengubah Joseon menjadi Kekaisaran Korea pada 1897.',
			'Namun usaha ini datang terlambat — Jepang telah memenangkan perang melawan Tiongkok dan Rusia.',
			'Jepang secara bertahap memperluas kendalinya lewat serangkaian perjanjian yang memaksa.',
			'Pada 1910, Jepang mencaplok sepenuhnya Korea, mengakhiri lebih dari 500 tahun kekuasaan Joseon.',
		]}
	>
		<Motif variant="flagFall" accent={colors.cinnabar} />
	</SceneShell>
);
