import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene07Isolation: React.FC = () => (
	<SceneShell
		sealHangeul="쇄국"
		sealLabel="HERMIT KINGDOM"
		title="Isolasi dan Kemunduran"
		subtitle="Faksi istana dan pemberontakan rakyat"
		accent={colors.ink}
		narration={[
			'Setelah dua invasi besar, Joseon memilih jalan isolasi — dijuluki bangsa Barat "Hermit Kingdom".',
			'Persaingan antar faksi politik sadaebu semakin memanas, lebih mementingkan perebutan kekuasaan.',
			'Pajak berat dan bencana memicu pemberontakan, termasuk Pemberontakan Petani Donghak pada 1894.',
			'Kekuatan asing mulai memaksa Joseon membuka diri lewat perjanjian yang tidak setara, terutama dengan Jepang.',
		]}
	>
		<Motif variant="gate" accent={colors.ink} opacity={0.12} />
	</SceneShell>
);
