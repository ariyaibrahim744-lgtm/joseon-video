import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene06War: React.FC = () => (
	<SceneShell
		sealHangeul="임진"
		sealLabel="1592–1598"
		title="Ancaman dari Luar: Perang Imjin"
		subtitle="Invasi Jepang dan kapal kura-kura"
		accent={colors.indigo}
		narration={[
			'Pada 1592, Jepang di bawah Toyotomi Hideyoshi melancarkan invasi besar-besaran ke Joseon.',
			'Laksamana Yi Sun-sin, dengan kapal geobukseon atau kapal kura-kura, menghancurkan armada laut Jepang.',
			'Dengan bantuan pasukan Ming, Joseon memukul mundur invasi ini pada 1598 — meski kerusakannya sangat besar.',
			'Belum lama pulih, Joseon kembali diserang Dinasti Qing pada 1636, dan dipaksa tunduk sebagai negara bawahan.',
		]}
	>
		<Motif variant="waves" accent={colors.indigo} />
	</SceneShell>
);
