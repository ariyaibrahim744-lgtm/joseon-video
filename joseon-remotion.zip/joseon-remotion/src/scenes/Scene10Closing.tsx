import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene10Closing: React.FC = () => (
	<SceneShell
		sealHangeul="끝"
		sealLabel="PENUTUP"
		title="Dinasti yang Mendefinisikan Korea"
		accent={colors.brass}
		narration={[
			'Dari sebuah kudeta militer hingga menjadi peradaban paling berpengaruh di Asia Timur.',
			'Joseon membuktikan bahwa lebih dari lima abad sejarah bisa membentuk identitas sebuah bangsa hingga hari ini.',
			'Dinasti yang tak hanya memerintah Korea — tapi juga mendefinisikan siapa itu Korea.',
		]}
	>
		<Motif variant="sunburst" accent={colors.brass} />
	</SceneShell>
);
