import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene03Confucian: React.FC = () => (
	<SceneShell
		sealHangeul="유교"
		sealLabel="TATANAN BARU"
		title="Fondasi Konfusianisme"
		subtitle="Birokrasi, ujian negara, dan hierarki sosial"
		accent={colors.jade}
		narration={[
			'Berbeda dari Goryeo yang berorientasi Buddha, Joseon membangun fondasinya di atas Konfusianisme Neo.',
			'Sistem ini melahirkan birokrasi berbasis ujian negara yang disebut gwageo.',
			'Meski begitu, kelas yangban tetap mendominasi karena hanya mereka yang punya akses pendidikan.',
			'Masyarakat kemudian terbagi: yangban, rakyat jelata sangmin, kelas rendah cheonmin, dan budak nobi.',
		]}
	>
		<Motif variant="gate" accent={colors.jade} />
	</SceneShell>
);
