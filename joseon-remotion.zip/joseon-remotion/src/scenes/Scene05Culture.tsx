import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene05Culture: React.FC = () => (
	<SceneShell
		sealHangeul="문화"
		sealLabel="KEHIDUPAN SEHARI-HARI"
		title="Kehidupan dan Budaya"
		subtitle="Keluarga, hanbok, hanok, dan kesenian"
		accent={colors.cinnabar}
		narration={[
			'Kehidupan sehari-hari sangat diwarnai Konfusianisme — keluarga menjadi unit sosial terpenting.',
			'Busana hanbok yang berwarna-warni menjadi identitas visual era ini.',
			'Rumah tradisional hanok dengan sistem pemanas lantai ondol menunjukkan kecerdasan arsitektur.',
			'Kesenian berkembang pesat: lukisan minhwa, keramik seladon dan porselen putih, hingga sastra klasik.',
		]}
	>
		<Motif variant="textilePattern" accent={colors.cinnabar} opacity={0.12} />
	</SceneShell>
);
