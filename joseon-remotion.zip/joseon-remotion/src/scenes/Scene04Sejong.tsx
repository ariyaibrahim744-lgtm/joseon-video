import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene04Sejong: React.FC = () => (
	<SceneShell
		sealHangeul="세종"
		sealLabel="1418–1450"
		title="Zaman Keemasan: Raja Sejong"
		subtitle="Aksara, sains, dan penemuan bagi rakyat"
		accent={colors.brass}
		narration={[
			'Raja Sejong Yang Agung memerintah Joseon dalam era ledakan inovasi di berbagai bidang.',
			'Pencapaian paling monumentalnya: penciptaan Hangeul pada 1443, aksara yang mudah dipelajari rakyat biasa.',
			'Sejong ingin setiap rakyatnya bisa membaca dan menulis — gagasan yang jauh mendahului zamannya.',
			'Era ini juga melahirkan jam matahari, jam air, alat pengukur curah hujan pertama di dunia, hingga kemajuan kedokteran.',
		]}
	>
		<Motif variant="characters" accent={colors.brass} />
	</SceneShell>
);
