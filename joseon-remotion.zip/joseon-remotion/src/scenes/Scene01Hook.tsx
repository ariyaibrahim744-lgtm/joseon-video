import React from 'react';
import { SceneShell } from '../components/SceneShell';
import { Motif } from '../components/Motif';
import { colors } from '../theme';

export const Scene01Hook: React.FC = () => (
	<SceneShell
		sealHangeul="조선"
		sealLabel="JOSEON"
		title="Dinasti yang Membentuk Korea"
		subtitle="Lebih dari 500 tahun sejarah"
		accent={colors.indigo}
		narration={[
			'Lebih dari 500 tahun. Itulah usia satu dinasti yang mengubah semenanjung kecil di Asia Timur.',
			'Dinasti itu bernama Joseon — dan warisannya masih hidup di setiap sudut Korea modern hari ini.',
			'Dari mana ia lahir, dan bagaimana ia bisa bertahan selama lebih dari lima abad?',
		]}
	>
		<Motif variant="mountains" accent={colors.indigo} />
	</SceneShell>
);
